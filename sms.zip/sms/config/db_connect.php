<?php
// Database configuration
$host = "localhost:3306";
$user = "root";       
$pass = "";           
$dbname = "student_db"; 

// Establish database connection
$conn = mysqli_connect($host, $user, $pass, $dbname);

// Verify database connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}
// Improve session persistence: extend server GC lifetime and refresh session cookie when active
@ini_set('session.gc_maxlifetime', 86400); // 24 hours
// If a session is already started by the including script, refresh the session cookie expiry
if (session_status() === PHP_SESSION_ACTIVE) {
    // extend cookie for 24 hours from now
    setcookie(session_name(), session_id(), time() + 86400, '/');
}
?>