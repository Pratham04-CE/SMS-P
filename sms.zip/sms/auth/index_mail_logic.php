<?php
// Setup absolute path to avoid directory reference errors from subfolders
$root = $_SERVER['DOCUMENT_ROOT'] . '/Pratham/sms/'; 

require $root . 'vendor/PHPMailer/Exception.php';
require $root . 'vendor/PHPMailer/PHPMailer.php';
require $root . 'vendor/PHPMailer/SMTP.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

function sendVerificationMail($email, $name, $otp) {
    // Send email verification logic
    $mail = new PHPMailer(true);
    try {
        $mail->isSMTP();
        $mail->Host = 'smtp.gmail.com';
        $mail->SMTPAuth = true;
        $mail->Username = 'studentmanagementsystem04@gmail.com'; 
        $mail->Password = 'ljiawcqbthqwyuzp';              
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
        $mail->Port = 587;

        $mail->setFrom('studentmanagementsystem04@gmail.com', 'SMS Portal');
        $mail->addAddress($email);

        $mail->isHTML(true);
        $mail->Subject = 'Login Verification Code';
        $mail->Body    = "<h3>Hello $name,</h3>
                          <p>Your verification code for login is: <b>$otp</b></p>";

        return $mail->send();
    } catch (Exception $e) {
        return false;
    }
}
function sendLowAttendanceMail($email, $name, $percent) {
    // Uses the imported PHPMailer class directly
    $mail = new PHPMailer(true); 
    
    try {
        $mail->isSMTP();
        $mail->Host = 'smtp.gmail.com';
        $mail->SMTPAuth = true;
        $mail->Username = 'studentmanagementsystem04@gmail.com'; 
        $mail->Password = 'ljiawcqbthqwyuzp'; 
        $mail->SMTPSecure = 'tls';
        $mail->Port = 587;

        $mail->setFrom('studentmanagementsystem04@gmail.com', 'SMS Admin');
        $mail->addAddress($email);
        $mail->isHTML(true);
        $mail->Subject = 'Low Attendance Warning - SMS Portal';
        $mail->Body    = "<h3>Hello $name,</h3>
                          <p>Your attendance is <b>$percent%</b>, which is below 75%.</p>
                          <p>Please attend classes regularly.</p>";

        return $mail->send();
    } catch (Exception $e) {
        return false;
    }
}
?>